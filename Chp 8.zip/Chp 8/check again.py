import random

for x in range(0,1000):
    b = random.randint(100,999)
    
if b%5 == 0:
    for a in range(0,3):
        print(b)