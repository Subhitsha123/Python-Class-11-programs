import math

num = int(input("Enter a number: "))
sq = int(math.sqrt(num))

print("The given number is",num)

x = ''

if num != 1:
    for a in range(2,sq):
        if sq%a == 0:
            x = 1

    if x == 1:
        print("The square root of",num,"is composite")

    else:
        print("The square root of",num,"is prime")

else:
    print(num, "is neither odd nor prime!")