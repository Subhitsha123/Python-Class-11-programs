a = float(input("Enter the first number: "))
b = float(input("Enter the second number(other than 0): "))

print(f"The number given are {a} and {b} ")

if a%b == 0:
    print(f"The first number {a} is fully divisible {b}")

else:
    print(f"The first number {a} is not fully divisible {b}")    

    