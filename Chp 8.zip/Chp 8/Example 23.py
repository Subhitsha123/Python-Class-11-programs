l = float(input("Enter the length: "))
w = float(input("Enter the width: "))
h = float(input("Enter the height: "))

print("The given length is",l)
print("The given width is",w)
print("The given height is",h)

area = l*h
perimeter = 2*(l+w)

print("The area is",area)
print("The perimeter is",perimeter)
