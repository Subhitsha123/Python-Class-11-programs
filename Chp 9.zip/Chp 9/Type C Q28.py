temp = float(input("Enter the temperature: "))
print("What unit?")
val = int(input("Enter 1 for Celsius to Fahrenheit and 2 for Fahrenheit to Celsius "))

if val == 1:
    new_temp = 9/5*temp+32
    print(temp,"C = ",new_temp,"F")

elif val == 2:
    new_temp = 5/9*(temp-32)
    print(temp,"F = ",new_temp,"C")

else:
    print("Enter only 1 or 2 for unit!")
