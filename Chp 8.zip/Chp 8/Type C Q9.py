x = input("Enter the day: ")
y = input("Enter the month: ")

if len(x)==4:
    day  = int(x[3])
    
else:
    day  = int(x[3])*10+int(x[4])

if len(y)==6:
     month = int(y[5])

else:
    month = int(y[5])*10+int(y[6])

print("Day of the year: ", (month-1)*30 + day)