p = float(input("Enter principal amount: "))
r = float(input("Enter the interest rate: "))
t = float(input("enter time period in years: "))

CI = (p*(1+r/100)**(t))

print("The amount payable is",CI)