p = float(input("Enter principal amount: "))
r = float(input("Enter the interest rate: "))
t = float(input("enter time period in years: "))

SI = (p*r*t)/100
CI = (p*(1+r/t)**(r*t)) - p

print("Simple interest = ",SI)
print("Compound interest = ",CI)
