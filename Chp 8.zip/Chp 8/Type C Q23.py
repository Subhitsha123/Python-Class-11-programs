PA = float(input("Enter the Principal amount: "))
IR = float(input("Enter the interest rate: "))
time = float(input("Enter the time period: "))

SI = (PA*IR*time)/100

print(f"The Principal amount is {PA} , The interest rate is {IR} and the time period is {time}")
print(f"The simple interest is {SI}")

print(f"The amount payable is {SI+PA}")