print("Enter values greater then 0")
side_1 = float(input("Enter side 1 of the triangle: "))
side_2 = float(input("Enter side 2 of the triangle: "))
side_3 = float(input("Enter side 3 of the triangle: "))

print("The given sides are",side_1,",",side_2,",",side_3)

if side_1<=0 or side_2<=0 or side_3<=0:
    print("This is invalid!")

elif side_1+side_2>side_3 and side_2+side_3>side_1 and side_1+side_3>side_2: 
    if side_1 == side_2 == side_3:
        print("This is an equilateral triangle")

    elif side_1 == side_2 or side_2 == side_3 or side_1 == side_3:
        print("This is an isosceles triangle")

    else:
        print("This is a scalene triangle")

else:
    print("Enter valid sides of triangle!")
