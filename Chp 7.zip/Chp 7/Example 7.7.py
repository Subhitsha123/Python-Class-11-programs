# Converting tonnes into quintals and kg
tonnes = float(input("Enter tonnes: "))
quintals = tonnes*10
kg = quintals*100

print("Tonnes: ",tonnes)
print("Quintals: ",quintals)
print("Kilograms: ",kg)