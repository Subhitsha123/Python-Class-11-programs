for i in range(1,5):
    for a in range(1,i):
        print('*',end = ' ')
    print()
    
for i in range(1,3):   
    for x in range(3,i,-1):
        print('*',end = ' ')
    print()
    
           
        


