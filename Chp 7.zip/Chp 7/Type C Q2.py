date = int(input("Enter today's date: "))
month = input("Enter the month(all small letters): ")
year = int(input("Enter year: "))

if month == 'january' or  month== 'march' or month == 'may' or month =='july' or month =='august' or month== 'october' or month == 'december':
    print("Number of days remaning =", 31-date)
    

elif month == 'april' or month == 'june' or month == 'september' or month == 'november':
    print("Number of days remaning =",30-date)  

elif month == 'february' and year%4 == 0 and year%400 == 0:
    print("Number of days remaining =",29-date)

else:
    print("Number of days remaining =",28-date)   
    