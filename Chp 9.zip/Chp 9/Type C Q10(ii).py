i = 1
j = -4
neg = 1

for a in range(1,41,3):
    print(a*neg,end = '  ')

    neg*=-1
