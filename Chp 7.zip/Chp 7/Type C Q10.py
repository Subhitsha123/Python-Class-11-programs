height = float(input("Enter height of the triangle: "))
base = float(input("Enter base of the triangle: "))

print("Height =",height)
print("Base =",base)

area = 0.5*height*base
print("The area of the triangle is ",area)