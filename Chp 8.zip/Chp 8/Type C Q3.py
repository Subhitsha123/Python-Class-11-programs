import math
x = float(input("Enter x: "))
y = float(input("Enter y: "))
z = float(input("Enter z: "))

result = 4*(math.pow(x,4))+ 3*(math.pow(y,3)) + 9*z +6*math.pi

print(f"x = {x}, y = {y}, z = {z}")
print(f"The result is {result}")

