a = int(input("Enter the number: "))
p,q,r,s,t = a*1,a*2,a*3,a*4,a*5
print("The first five multiples of ",a," is ",p, q, r, s, t)
