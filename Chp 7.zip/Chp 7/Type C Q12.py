a = int(input("Enter the number: "))
print("The first five multiples of ",a," is ",a*1, a*2, a*3, a*4, a*5)
