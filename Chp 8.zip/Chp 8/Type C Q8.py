num = input("Enter the number to be reversed: ")
print(f"The number given is {num}")

a = num[0]
b = num[1]
c = num[2]

print(f"The reversed number is {c}{b}{a}")