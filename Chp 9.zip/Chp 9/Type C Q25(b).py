for x in range(1,6):
    for i in range(0,x):
        print(chr(64+x),end =' ')
    print()
