#Calculating BMI of a person
weight = float(input("Enter weight in kg: "))
height = float(input("Enter height in m: "))

bmi = weight/(height**2)

print("The BMI is ",bmi)