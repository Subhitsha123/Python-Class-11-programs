height = float(input("Enter the height in cm "))
print("The given height is",height,"cm")

inch = height/2.54 
foot = inch//12 
rem_inch = inch%12 

print(f"The height of the person in inches and feet is {foot} feet {rem_inch} inches")
