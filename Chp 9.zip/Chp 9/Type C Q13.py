a = int(input("Enter a number: "))
fl = str(a)
l = []

for i in fl:
    l.append(i)

if l[len(l)-1]=='4':
    print(a,"ends with 4")

elif l[len(l)-1]=='8':
    print(a,"ends with 8")

else:
    print(a,"ends with neither")

