import math
a = float(input("Enter a: "))
b = float(input("Enter b: "))

print("(a+b)^3 is",(math.pow(a,3))+(math.pow(b,3))+(3*(math.pow(a,2)*b))+(3*(a*math.pow(b,2))))
