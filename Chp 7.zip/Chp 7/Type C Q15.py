#Swapping three numbers after addition
a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
c = int(input("Enter the third number: "))

print("Before swapping numbers were ",a,b,c,sep = ',')

a = a+b
b = b+c

print("After swapping numbers are ",a,b,sep = ',')