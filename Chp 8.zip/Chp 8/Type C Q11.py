age = int(input("What is your age? "))
if age>=0: 
    print(f"In ten years you will be {age+10} years old!")

else: 
    print("Enter a valid age!") 