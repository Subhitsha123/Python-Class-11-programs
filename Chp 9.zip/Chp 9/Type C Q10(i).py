n =-2
for a in range(1,41,3):
    print(a,end = '  ')