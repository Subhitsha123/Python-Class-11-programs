mark_1 = float(input("Enter the marks of first subject: "))
mark_2 = float(input("Enter the marks of second subject: "))
mark_3 = float(input("Enter the marks of third subject: "))
mark_4 = float(input("Enter the marks of fourth subject: "))
mark_5 = float(input("Enter the marks of fifth subject: "))

print("Given marks are ",mark_1,mark_2,mark_3,mark_4,mark_5)

avg = (mark_1+mark_2+mark_3+mark_4+mark_5)/5

print("The average marks is: ",avg)