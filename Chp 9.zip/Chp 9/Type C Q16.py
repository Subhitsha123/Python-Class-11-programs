largest = -1
second = -1

print("Enter as many number as you want. If you want to stop input 'x' or 'X' ")
while True :
    num = input("enter a number = ")
    if num == 'x' or num == 'X' :
        break
    elif num != 'x' or num != 'X' :
        a = int(num)
        if a  > largest :
            second  = largest
            largest = a
        elif a != largest and a > second :
            second = a
print(second,"is second biggest number ")