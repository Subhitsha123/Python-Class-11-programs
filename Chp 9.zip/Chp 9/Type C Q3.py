hour = int(input("Enter a time from 1-12: "))
extra = int(input("Enter the number of hours ahead: "))

print("The given time is",hour )
print("The given number of hours ahead is",extra)

time = hour+extra

if time<=12:
    print("The time is",time,"o'clock")

if time>12:
    print("The time is", time-12,"o'clock")
    