rows = 6
per_row = 20

for i in range(rows):
    for j in range(per_row):
        print('*',end = ' ')
    print()