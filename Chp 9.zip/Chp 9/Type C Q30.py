n = int(input("Enter the number: "))

if n>1:
    for x in range(1,n+1):
        for a in range(2,n+1):            
            if x !=a :
                 
                if (x % a) == 0:                    
                    print("Composite")                      
                    break
    
            else:
                continue
                print(x,"yo","Prime")
        else:
            print(x,"num","Prime number")