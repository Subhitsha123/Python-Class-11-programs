#Adding three numbers
num_1 = int(input("Enter the first number: "))
num_2 = int(input("Enter the second number: "))
num_3 = int(input("Enter the third number: "))

sum = num_1 + num_2 +num_3
print(sum)