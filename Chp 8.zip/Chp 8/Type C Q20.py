import math

rad = float(input("Enter the radius: ")) 
height = float(input("Enter the height: ")) 

print("The radius and height given is",rad,"and",height)

vol = math.pi*math.pow(rad,2)*height

print("The volume is",vol)
