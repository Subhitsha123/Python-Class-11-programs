myNumber = 10
print(myNumber+1)
print(myNumber)
print(type(myNumber))
myNumber =5+2
print(myNumber,end = '')
print(type(myNumber))
myNumber = "Seven"
print(myNumber)
print(type(myNumber))
