num = int(input("Enter the number: "))
print("The given number is",num)
dup = num
rev_no = 0
count = 0

while dup>0:
    rem = dup%10
    rev_no = (rev_no*10)+rem
    dup = dup//10
    count+=1

dig = count
msn = rem

print("The output number is:",dig*10+msn)





