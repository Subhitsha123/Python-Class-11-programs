import statistics

mon = float(input("Enter the temperature: "))
tue = float(input("Enter the temperature: "))
wed = float(input("Enter the temperature: "))
thur = float(input("Enter the temperature: "))
fri = float(input("Enter the temperature: "))
sat = float(input("Enter the temperature: "))
sun = float(input("Enter the temperature: "))

days = [mon,tue,wed,thur,fri,sat,sun]
avg = statistics.mean(days)

print("Print the average temperture is:",avg)