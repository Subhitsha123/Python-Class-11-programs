import math
side  = float(input("Enter the side of the triangle: "))

print("The given side is:",side)
area = (math.sqrt(3)/2)*side*side

print("The area is:",area)