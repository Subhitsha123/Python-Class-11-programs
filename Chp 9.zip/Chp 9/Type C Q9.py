n = int(input("Enter n: "))

print("The first",n,"odd numbers in descending order is")
for a in range((n*2)-1,0,-1):
    if(a%2 != 0):
        print(a,end = ' ')


  
