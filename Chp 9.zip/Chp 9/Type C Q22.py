n = int(input("Enter number of employee: "))

count_1 = 0
count_2 = 0
count_3 = 0

for i in range(n):
    age = int(input("Enter the age of the employees: "))

    if age in range(26,36):
        count_1+=1 

    if age in range(36,46):
        count_2+=1

    if age in range(46,56):
        count_3+=1

print("No.of employees between 26-35 is:",count_1)
print("No.of employees between 36-45 is:",count_2)
print("No.of employees between 46-55 is:",count_3)