a = input("Enter the string: ")

print(a*len(a))
