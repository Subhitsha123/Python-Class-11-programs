n = int(input("Enter n: "))
print("The given value of n is",n)
mul = 1
sum = 0

for i in range(1,n+1):
    mul = mul*i
    sum = sum +(1/mul)

print(sum+1)