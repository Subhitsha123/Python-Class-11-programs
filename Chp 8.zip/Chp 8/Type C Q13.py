import random as rd
import statistics as st

l = []

for i in [1,2,3,4,5,6]:
    num = rd.randrange(0,100,5)

    l.append(num)

print("The numbers taken are",l)
mean = st.mean(l)
median = st.median(l)
mode = st.mode(l)

print("The mean is:",mean,"\n", "The median is:", median, "\n", "The mode is:",mode,"\n")