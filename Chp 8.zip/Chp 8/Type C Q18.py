import math as m
area = float(input("Enter the area: "))

print("The area given is",area)

radius = m.sqrt(area/(4*m.pi))

print("The radius is",radius)