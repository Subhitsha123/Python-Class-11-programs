a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))
c = float(input("Enter the third number: "))

print("The numbers are",a,b,c)

avg = (a+b+c)/3

print("The average is",avg)