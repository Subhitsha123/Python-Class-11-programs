dig = int(input("Enter a digit: "))
print("The given digit is",dig)

if dig>=0 and dig<10:
    if dig == 0:
        print(dig,"in words is zero")

    elif dig == 1:
        print(dig,"in words is one")

    elif dig == 2:
        print(dig,"in words is two")

    elif dig == 3:
        print(dig,"in words is three")

    elif dig == 4:
        print(dig,"in words is four")

    elif dig == 5:
        print(dig,"in words is five")

    elif dig == 6:
        print(dig,"in words is six")

    elif dig == 7:
        print(dig,"in words is seven")

    elif dig == 8:
        print(dig,"in words is eight")

    elif dig == 9:
        print(dig,"in words is nine")

else:
    print("Enter a valid digit!")
