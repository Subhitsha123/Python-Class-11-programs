length = float(input("Enter a length in cm: "))
print("The give length is",length,"cm")

if length<0:
    print("Entry is invalid")

else:
    inch = length/2.54
    print("The lenth is",inch,"inches")