date = int(input("Enter today's date: "))
month = input("Enter the month(all small letters): ")
year = int(input("Enter year: "))

if month in ('january','march' ,'may' ,'july' ,'august' ,'october' ,'decemeber'):
    print("Number of days remaning =",31-date)
    

elif month in ('april','june','september','november'):
    print("Number of days remaning =",30-date)  

elif month == 'february' and  year%4 == 0 and year%400 == 0:
    print("Number of days remaining =",29-date)

else:
    print("Number of days remaining =",28-date)