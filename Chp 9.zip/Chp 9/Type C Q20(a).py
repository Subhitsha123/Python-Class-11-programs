count = 0
i = -1
j = 5
sum = 0
neg = 1

for k in range(7):
    i+=3
    j+=4
    
    sum = sum+(i/j)*neg
    neg = neg*-1

print(sum)