a = float(input("Enter side 1 of triangle: "))
b = float(input("Enter side 2 of triangle: "))
c = float(input("Enter side 3 of triangle: "))

print("The given sides of the triangle are",a,",",b,",",c)

if a <= 0 or b <= 0 or c <= 0:
    print("This is not a traingle")

else: 
    if a+b>c and b+c>a and a+c>b: 
        print("This is a triangle")        

    else:
        print("This is not a triangle")