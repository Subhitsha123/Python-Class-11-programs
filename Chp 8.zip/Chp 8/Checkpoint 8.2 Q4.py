from platform import java_ver


r =2.5+3.9j
print(r.real)
print(r.imag)
