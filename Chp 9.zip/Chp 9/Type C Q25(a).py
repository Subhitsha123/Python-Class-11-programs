for x in range(1,7):
    for i in range(0,x):
        print(chr(65+i), end = ' ')
    print()