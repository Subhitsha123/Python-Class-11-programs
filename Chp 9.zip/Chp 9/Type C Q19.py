n = int(input("Enter the value of n: "))
m = int(input("Enter the value of m: "))

print("The given value of n is",n)
print("The given value of m is",m)

for i in range(2,n):
    if i%m == 0:
        if i%2 == 0:
            print(i,"- even")

        else:
            print(i,"- odd")

    