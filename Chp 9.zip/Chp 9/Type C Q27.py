A = float(input("Enter A: "))
B = float(input("Enter B: "))
C = float(input("Enter C: "))

print("A,B,C are",A,",",B,",",C)

if A>B and A>C:
    gr = A
    if B>C:
        sec = B
        th = C

    else:
        sec = C
        th = B

elif B>A and B>C:
    gr = B
    if A>C:
        sec = A
        th = C

    else:
        sec = C
        th = A

elif C>A and C>B:
    gr = C
    if A>B:
        sec = A
        th = B

    else:
        sec = B
        th = A
    
print("Smallest number =",th)
print("Next highest number =",sec)
print("Highest number =",gr)
    

