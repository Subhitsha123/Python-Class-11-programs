a = 5
b = a*2
c = b-1
print(a,"@",b,"@",c,sep = '')