rad = float(input("Enter the raduis of the circle "))
print("The radius is", rad)

ar = 3.14*(rad**2)
print("Area of circle: ",ar)