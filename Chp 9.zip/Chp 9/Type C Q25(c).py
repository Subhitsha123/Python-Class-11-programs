n = 5
count = 0
for x in range(0,2*n):
    if x%2 == 0:
        l = x
        count = count+1
       
        for i in range(count):
            print(l,end = '  ')
        print()
        