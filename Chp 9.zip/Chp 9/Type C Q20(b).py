sum = 0
n = int(input("Enter n: "))
print("The given value of n is",n)
for i in range(1,n+1,2):
    sum = sum+i**2

print(sum)