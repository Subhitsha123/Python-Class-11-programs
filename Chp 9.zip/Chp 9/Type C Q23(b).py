x = int(input("enter x: "))
n = int(input("enter n: "))
sum = 0

for k in range(1,n+1):
    sum = sum+ (x**k)/k

print(sum)