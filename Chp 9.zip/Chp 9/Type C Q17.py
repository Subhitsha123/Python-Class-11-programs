j =0
print("Enter 'x' to find which of them are palindromes")
l = []
while True:
    n = input("Enter the numbers: ")

    if n == 'x' or n == 'X':
        break
    
    num = int(n)
    dup = num
    rev_no = 0

    while dup>0:
        rem = dup%10
        rev_no = (rev_no*10)+rem
        dup = dup//10

        if num == rev_no:
            l.append(num)

# This is done to remove the brackets from the list
new_list  = str(l)[1:-1]

if len(l)<2:
    print("Out of the numbers",new_list,"is a palindrome")

else:
    print("Out of the numbers",new_list,"are palindromes")

       