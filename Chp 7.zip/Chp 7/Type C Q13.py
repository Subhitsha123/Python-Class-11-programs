_name = input("Enter name: ")
_age = input("Enter age: ")
_class = input("Enter class: ")

print(_name,_age,_class)
print("\n\n")
print(_name,"\n",_age,'\n',_class)
