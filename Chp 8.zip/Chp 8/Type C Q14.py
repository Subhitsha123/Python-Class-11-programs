import random

l = []

for i in [1,2,3]:
 otp = random.randrange(100,999,5)

 otps = l.append(otp)

print("The three random integers are",l)
