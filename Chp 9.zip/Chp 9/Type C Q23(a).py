x = int(input("Enter x: "))
n = 6
mul = 1
sum = 0
neg = 1

for i in range(1,n+1):
    mul = mul*i
    sum = sum+neg*(x**i/mul)
    neg*=-1
 

print(sum)