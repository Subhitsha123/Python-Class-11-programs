# Converting km to miles
km = float(input("Enter km: "))

miles = km*0.621371

print(km,"kilometres is ",miles," miles")