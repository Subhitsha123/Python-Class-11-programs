#Finding the cube of a number
num = int(input("Enter the number: "))

cube = num**3

print("Cube of ",num,"is",cube)