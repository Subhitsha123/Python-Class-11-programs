years = int(input("How many years? "))
print(f"{years} years is: \n {years * 365} days \n {years * 365*24} hours \n {years * 365*24*60} minutes \n {years * 365*24*60*60} minutes")