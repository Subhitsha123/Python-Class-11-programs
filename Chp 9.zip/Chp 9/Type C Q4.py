num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))

print("The first number is",num1)
print("The second number is",num2)

if num1>num2:
    diff = num1-num2

if num1<num2:
    diff = num2-num1

if diff <=0.001:
    print("Close")

if diff> 0.001:
    print("Not close")