a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))

sum = a+b
difference = a-b
product = a*b
quotient = a/b
modulus = a%b

print("The numbers are",a,b)
print("The sum is ",sum)
print("The difference is ",difference)
print("The product is ",product)
print("The quotient is ",quotient)
print("The modulus is ",modulus)