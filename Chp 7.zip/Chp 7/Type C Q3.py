a = 5
print(a)

a = a*2
print (a)

a = a-1
print(a)