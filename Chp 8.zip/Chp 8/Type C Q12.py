import random
import math

for i in [1,2,3]:
    a = random.randint(0,5)
    b = random.randint(0,5)

    print("The random numbers are",a,"and",b)
    print("A to the power B is",math.pow(a,b))