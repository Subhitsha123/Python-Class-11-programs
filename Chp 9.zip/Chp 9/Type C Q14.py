N = int(input("Input a number greater than 20: "))
print("The given number is",N)

for i in range(11,N+1):
    if i%7 == 0 and i%3 == 0:
        print("Tipsy Topsy")

    elif i%3 == 0:
        print("Tipsy")

    elif i%7 == 0:
        print("Topsy")

    else:
        print(i)