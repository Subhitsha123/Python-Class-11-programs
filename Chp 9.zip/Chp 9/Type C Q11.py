count = 0
sum = 0
print("Enter 'x' to print the average")
while True:
    n = input("Enter the numbers:")
    if n == 'x' or n == 'X':
        break
    if n!= 'x' or n!= 'X':
        num = int(n)
        count+=1
        sum = sum+num
    
print("The average  = ",sum/count)

        
        

    