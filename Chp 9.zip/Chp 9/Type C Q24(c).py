n = 3

for i in range(n): 
    for j in range(i,n):
        print(' ',end = '')
    print('*',end = '')    

    for j in range(i):
        print(' ',end = '')

    for j in range(i-1):
        print(' ',end = '')

    for j in range(i):
        print('*',end = '')
        if i ==2:
            break
   

    print()

for i in range(n-1):
    for j in range(i+2):
        print(' ',end = '')
    print('*',end = '')    
    

    for j in range(i,n-2):
        print(' ',end = '')

    if i != 1:       
        print('*',end = '')
        print()    
