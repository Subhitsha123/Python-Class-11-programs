sec = int(input("Enter the number of seconds: "))

print(f"The given number of seconds is {sec}")

min = sec//60
rem_sec = sec%60

print(f"The time in mins and secs is {min} minutes {rem_sec} seconds")