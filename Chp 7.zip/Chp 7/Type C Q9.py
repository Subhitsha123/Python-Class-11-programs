n = int(input("Enter the number: "))

print("The given number is", n)

print("n^2 = ",n**2)
print("n^3 = ",n**3)
print("n^4 = ",n**4)