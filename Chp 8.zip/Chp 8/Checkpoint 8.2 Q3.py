p = 3j
q = p+(1+1.5j)
print(p)
print(q)