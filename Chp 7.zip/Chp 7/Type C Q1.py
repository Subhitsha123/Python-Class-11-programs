print("What's a computer's favorite beat?")
a = input("Press enter to see the answer")
print("An algo-rythm")