l = int(input("Enter the numbers: "))
while True:
    n = input("Enter the numbers: ")

    if n != 'x':
        num = int(n)
        
        if l>num:
            l = l

        else:
            l = num

    if n == 'x':
        break

print("The largest number is",l)



