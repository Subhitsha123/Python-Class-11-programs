a = int(input("Enter the first number: ")) 
b = int(input("Enter the second number: ")) 

print("At first the numbers are ", a, b)


c = a 
a = b
b = c  

print("The numbers after swapping are ", a,b )