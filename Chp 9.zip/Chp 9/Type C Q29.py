temp = float(input("Enter the temperature in celsius: "))
print("The given temperature is",temp)

if temp<-273.15:
    print("Temperature is invalid because it is below absolute 0")

elif temp == -273.15:
    print("Temperature is absolute 0")

elif temp>-273.15 and temp<0:
    print("The temperature is below freezing")

elif temp == 0:
    print("The temperature is at the freezing point")

elif temp>0 and temp<100:
    print("Temperaure is in normal range")

elif temp == 100:
    print("Temperature is at the boiling point")

elif temp>100:
    print("The temperature is above boiling point")
