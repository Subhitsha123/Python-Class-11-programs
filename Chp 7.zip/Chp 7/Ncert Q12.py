x = int(input("Enter number of days A worked: "))
y = int(input("Enter number of days B worked: "))
z = int(input("Enter number of days C worked: "))

days = (x*y*z)/(x*y+y*z+x*z)

print("Number of days A worked:",x)
print("Number of days B worked:",y)
print("Number of days C worked:",z)

print("The number of days if they work together is: ",days)