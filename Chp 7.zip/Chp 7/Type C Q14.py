n = int(input("Enter a number from 1 to 7: "))
print("The given number is:", n)

print(n,n+1,n+2, sep ='')