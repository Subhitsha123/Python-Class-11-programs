#Swapping two numbers
a = int(input("Enter the first number to be swapped: "))
b = int(input("Enter the second number to be swapped: "))

print("Original numbers",a,b)

a,b = b,a

print("After swapping", a,b)

