x = int(input("Enter the first number: "))
y = int(input("Enter the second number: "))
z = int(input("Enter the third number: "))

print(f"before swapping: {x,y,z}")

print(f"After swapping: {x,x+y,x+y+z}")