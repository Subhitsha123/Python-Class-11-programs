import random

otp = random.randint(100001,999999)
print(otp)