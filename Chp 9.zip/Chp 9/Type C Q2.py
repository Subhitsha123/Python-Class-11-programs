item = int(input("Enter the number of items bought: "))
print("The number of items brought is",item)

if item<10 and item>0:
    cost = item*120
    print("The total cost is: ",cost)

elif item>=10 and item<=99:
    cost = item*100
    print("The total cost is: ",cost)

elif item>=100:
    cost = item*70
    print("The total cost is: ",cost)

elif item<=0:
    print("Enter a valid number!")

