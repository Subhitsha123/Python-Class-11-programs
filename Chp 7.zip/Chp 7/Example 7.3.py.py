#Finding area of  arectangle by inputting length and breadth
len = float(input("Enter the length: "))
bre = float(input("Enter the breadth: "))

area = len*bre

print("The area is ",area)