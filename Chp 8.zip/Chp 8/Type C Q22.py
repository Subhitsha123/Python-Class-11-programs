import math

radius = float(input("Enter the radius of the circle: "))
print("The given radius is",radius)

volume = 4/3*math.pi*math.pow(radius,3)
print("The volume is",volume)
