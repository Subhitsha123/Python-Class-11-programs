n = 4


for i in range(n):
    print('*',end = ' ')

    for j in range(i-1):

        print(' ',end = ' ')
    
    if i != 0:
        print('*',end = ' ')

    
    print()

for i in range(n-1):
    print('*',end = ' ')

    for j in range(i,n-3):

        print(' ',end = ' ')
    
    if i != 2:
        print('*',end = ' ')
    
    print()

