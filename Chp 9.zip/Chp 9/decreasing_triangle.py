for i in range(5,1,-1):
    for j in range(1,i):
        print('@',end = ' ')
    print()
    